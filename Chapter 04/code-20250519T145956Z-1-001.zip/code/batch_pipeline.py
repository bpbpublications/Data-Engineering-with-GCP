import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, GoogleCloudOptions, StandardOptions
import json
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)

def parse_json(line):
    """Parse a single JSON line and return a dictionary."""
    logging.info("parse_json started")
    try:
        if not line.strip():  # Skip empty lines
            logging.warning("Skipping empty line")
            return None
        record = json.loads(line)
        if not isinstance(record, dict):
            logging.error(f"Invalid JSON, not a dictionary: {line}")
            return None
        return record
    except (json.JSONDecodeError, ValueError) as e:
        logging.error(f"Invalid JSON line: {line}, Error: {e}")
        return None

def validate_record(element):
    """Validate and convert record to match BigQuery schema."""
    logging.info("validate record started")
    try:
        if element is None:
            logging.error("Received None record")
            return None
        if not isinstance(element, dict):
            logging.error(f"Non-dict record: {element}")
            return None
        # Required fields
        required_fields = [
            'Product_ID', 'Sales_Date', 'Sales_Rep', 'Region', 'Sales_Amount',
            'Quantity_Sold', 'Product_Category', 'Unit_Cost', 'Unit_Price',
            'Customer_Type', 'Discount', 'Payment_Method', 'Sales_Channel',
            'Region_and_Sales_Rep'
        ]
        if not all(field in element for field in required_fields):
            logging.error(f"Missing fields in record: {element}")
            return None
        # Validate and convert types
        try:
            validated = {
                'Product_ID': int(element['Product_ID']),
                'Sales_Date': element['Sales_Date'],  # Assumes YYYY-MM-DD
                'Sales_Rep': str(element['Sales_Rep']),
                'Region': str(element['Region']),
                'Sales_Amount': float(element['Sales_Amount']),
                'Quantity_Sold': int(element['Quantity_Sold']),
                'Product_Category': str(element['Product_Category']),
                'Unit_Cost': float(element['Unit_Cost']),
                'Unit_Price': float(element['Unit_Price']),
                'Customer_Type': str(element['Customer_Type']),
                'Discount': float(element['Discount']),
                'Payment_Method': str(element['Payment_Method']),
                'Sales_Channel': str(element['Sales_Channel']),
                'Region_and_Sales_Rep': str(element['Region_and_Sales_Rep'])
            }
            return validated
        except (ValueError, TypeError) as e:
            logging.error(f"Type conversion error in record: {element}, Error: {e}")
            return None
    except Exception as e:
        logging.error(f"Validation error for record: {element}, Error: {e}")
        return None

def run():
    """Run the pipeline to process JSON files and write to BigQuery."""
    input_file = 'gs://bpb_data_engg_sales_data_files/sales_data.json'  # Update if different
    output_table = '******:bpb_data_engg_sales_db.regional_sales_db' # Replace asterix with your GCP project Id

    options = PipelineOptions()
    google_cloud_options = options.view_as(GoogleCloudOptions)
    google_cloud_options.project = '******' # Replace asterix with your GCP project Id
    google_cloud_options.region = 'us-central1'
    google_cloud_options.job_name = 'json-to-bq-job'
    google_cloud_options.staging_location = 'gs://bpb_data_engg_sales_data_files/staging'
    google_cloud_options.temp_location = 'gs://bpb_data_engg_sales_data_files/temp'
    options.view_as(StandardOptions).runner = 'DataflowRunner'

    with beam.Pipeline(options=options) as p:
        (
            p
            | 'Read JSON' >> beam.io.ReadFromText(input_file, skip_header_lines=0)  # No header in JSON
            | 'Parse JSON' >> beam.Map(parse_json)
            | 'Filter None (Parse)' >> beam.Filter(lambda x: x is not None)
            | 'Log Post-Parse' >> beam.Map(lambda x: logging.info(f"Post-parse: {x}") or x)
            | 'Validate Record' >> beam.Map(validate_record)
            | 'Filter None (Validate)' >> beam.Filter(lambda x: x is not None)
            | 'Log Valid' >> beam.Map(lambda x: logging.info(f"Valid record: {x}") or x)
            | 'Write to BigQuery' >> beam.io.WriteToBigQuery(
                output_table,
                schema=(
                    'Product_ID:INTEGER,Sales_Date:DATE,Sales_Rep:STRING,Region:STRING,'
                    'Sales_Amount:FLOAT,Quantity_Sold:INTEGER,Product_Category:STRING,'
                    'Unit_Cost:FLOAT,Unit_Price:FLOAT,Customer_Type:STRING,Discount:FLOAT,'
                    'Payment_Method:STRING,Sales_Channel:STRING,Region_and_Sales_Rep:STRING'
                ),
                write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
                create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED
            )
        )

if __name__ == '__main__':
    logging.info("Main execution started")
    run()