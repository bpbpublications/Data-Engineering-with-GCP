import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions
import json
import logging

logging.basicConfig(level=logging.INFO)

def validate_record(element):
    try:
        record = json.loads(element.decode('utf-8'))
        required_fields = [
            'product_id', 'sales_date', 'sales_rep', 'region', 'sales_amount',
            'quantity_sold', 'product_category', 'unit_cost', 'unit_price',
            'customer_type', 'discount', 'payment_method', 'sales_channel',
            'region_and_sales_rep'
        ]
        if not all(field in record for field in required_fields):
            logging.error(f"Missing fields: {record}")
            return None
        return {
            'product_id': int(record['product_id']),
            'sales_date': record['sales_date'],
            'sales_rep': str(record['sales_rep']),
            'region': str(record['region']),
            'sales_amount': float(record['sales_amount']),
            'quantity_sold': int(record['quantity_sold']),
            'product_category': str(record['product_category']),
            'unit_cost': float(record['unit_cost']),
            'unit_price': float(record['unit_price']),
            'customer_type': str(record['customer_type']),
            'discount': float(record['discount']),
            'payment_method': str(record['payment_method']),
            'sales_channel': str(record['sales_channel']),
            'region_and_sales_rep': str(record['region_and_sales_rep'])
        }
    except Exception as e:
        logging.error(f"Validation error: {element}, {e}")
        return None

options = PipelineOptions(
    project='******', # Replace asterix with your GCP project Id
    runner='DataflowRunner',
    temp_location='gs://bpb_data_engg_sales_data_files/temp',
    region='us-east1',
    streaming=True
)

with beam.Pipeline(options=options) as p:
    (p
     | 'Read from Pub/Sub' >> beam.io.ReadFromPubSub(subscription='projects/******/subscriptions/sales-subscription')  # Replace asterix with your GCP project Id
     | 'Validate Records' >> beam.Map(validate_record)
     | 'Filter None' >> beam.Filter(lambda x: x is not None)
     | 'Log Valid' >> beam.Map(lambda x: logging.info(f"Valid record: {x}") or x)
     | 'Write to BigQuery' >> beam.io.WriteToBigQuery(
         '*****:bpb_data_engg_sales_db.regional_sales_db', # Replace asterix with your GCP project Id
         schema=(
             'Product_ID:INTEGER,Sales_Date:DATE,Sales_Rep:STRING,Region:STRING,'
             'Sales_Amount:FLOAT,Quantity_Sold:INTEGER,Product_Category:STRING,'
             'Unit_Cost:FLOAT,Unit_Price:FLOAT,Customer_Type:STRING,Discount:FLOAT,'
             'Payment_Method:STRING,Sales_Channel:STRING,Region_and_Sales_Rep:STRING'
         ),
         write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
         create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED))