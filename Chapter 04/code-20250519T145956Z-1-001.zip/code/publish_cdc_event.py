import base64
import gzip
import io
import json
import os
import functions_framework
from cloudevents.http import CloudEvent
from google.cloud import pubsub_v1
from google.cloud import storage
import logging
import re

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Get environment variables
TOPIC_ID = 'sales-topic'
PROJECT_ID = '******' # Replace asterix with your GCP project Id

# Initialize clients
publisher = pubsub_v1.PublisherClient()
storage_client = storage.Client()
topic_path = publisher.topic_path(PROJECT_ID, TOPIC_ID)


@functions_framework.cloud_event
def publish_cdc_event(cloud_event: CloudEvent) -> str:
    """
    Cloud Function triggered by a Cloud Storage event that:
    1. Downloads a .json.gz file from Cloud Storage
    2. Decompresses the gzip file
    3. Processes the JSONL content line by line
    4. Publishes each JSON line to a Pub/Sub topic
    
    Args:
        cloud_event: The CloudEvent that triggered the function
    
    Returns:
        A string indicating the success or failure of the operation
    """
    try:
        # Extract the Cloud Storage event data
        storage_data = cloud_event.data
         # Log the complete cloud event data for debugging
        logger.info(f"Cloud event data: {json.dumps(storage_data, indent=2)}")                
        # Extract file details
        bucket_name = storage_data["bucket"]
        file_name = storage_data["name"]
        event_type = cloud_event["type"]
        event_id = cloud_event["id"]        
        logger.info(f"Received {event_type} event with ID: {event_id}")
        logger.info(f"Processing file: gs://{bucket_name}/{file_name}")        
        # Check if the file is a .jsonl.gz file
        if not file_name.lower().endswith('.jsonl.gz'):
            logger.info(f"Skipping non-JSON.GZ file: {file_name}")
            return f"Skipped non-JSON.GZ file: {file_name}"       
        # Download the gzipped file
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(file_name)
        gzipped_content = blob.download_as_bytes()        
        # Decompress the content
        try:
            with gzip.GzipFile(fileobj=io.BytesIO(gzipped_content), mode='rb') as f:
                decompressed_content = f.read().decode('utf-8')
            logger.info(f"Successfully decompressed content from {file_name}")
        except Exception as e:
            logger.error(f"Failed to decompress {file_name}: {str(e)}")
            return f"Error: Failed to decompress {file_name}: {str(e)}"       
        # Process as JSONL - each line is a separate JSON object
        lines = decompressed_content.splitlines()
        logger.info(f"Found {len(lines)} JSON lines in the file")        
        # Keep track of successful and failed lines
        successful_lines = 0
        failed_lines = 0       
        # Process each line
        for i, line in enumerate(lines):
            if not line.strip():  # Skip empty lines
                continue               
            try:
                logger.info(f"line {line}")
                # Parse the JSON to validate it
                json_data = json.loads(line)
               # Extract the 'payload' attribute
                if 'payload' not in json_data:
                    logger.warning(f"Line {i+1}: No 'payload' attribute found, skipping")
                    failed_lines += 1
                    continue               
                payload = json_data['payload']       
                str_payload = json.dumps(payload)
                pubsub_payload = str_payload.encode("utf-8")
                logger.info(f"pubsub_payload {pubsub_payload}")
                # Publish the message to Pub/Sub
                future = publisher.publish(topic_path, data=pubsub_payload)
                message_id = future.result()               
                successful_lines += 1                
                # Log only occasionally for large files to avoid excessive logging
                if successful_lines % 100 == 0 or successful_lines == 1:
                    logger.info(f"Published {successful_lines} messages so far")               
            except json.JSONDecodeError as e:
                logger.warning(f"Invalid JSON at line {i+1}: {str(e)}")
                failed_lines += 1
            except Exception as e:
                logger.error(f"Error publishing line {i+1}: {str(e)}")
                failed_lines += 1       
        summary = f"Processed {file_name}: {successful_lines} lines published successfully, {failed_lines} lines failed"
        logger.info(summary)
        return summary
    
    except Exception as e:
        error_message = f"Error processing gzipped JSONL file: {str(e)}"
        logger.error(error_message)
        return error_message