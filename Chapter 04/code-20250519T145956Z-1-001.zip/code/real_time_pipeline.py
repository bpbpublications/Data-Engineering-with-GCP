import json
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions, GoogleCloudOptions

class ParseMessage(beam.DoFn):
    def process(self, element):
        try:
            record = json.loads(element)
            # Add event_date field
            record['event_date'] = record['timestamp'].split('T')[0]
            return [record]
        except Exception as e:
            print(f"Parsing error: {e}")
            return []

def run():
    project_id = '******' # Replace asterix with your GCP project Id
    topic = 'projects/*****/topics/user-activity-topic' # Replace asterix with your GCP project Id
    output_table = '******:bpb_data_engg_sales_db.user_activity' # Replace asterix with your GCP project Id

    options = PipelineOptions()
    google_cloud_options = options.view_as(GoogleCloudOptions)
    google_cloud_options.project = project_id
    google_cloud_options.region = 'us-central1'
    google_cloud_options.job_name = 'pubsub-to-bq-etl-002'
    google_cloud_options.staging_location = 'gs://bpb_data_engg_sales_data_files/staging'
    google_cloud_options.temp_location = 'gs://bpb_data_engg_sales_data_files/temp'
    options.view_as(StandardOptions).runner = 'DataflowRunner'  # Or 'DirectRunner' for local testing

    with beam.Pipeline(options=options) as p:
        (
            p
            | 'Read from Pub/Sub' >> beam.io.ReadFromPubSub(topic=topic).with_output_types(bytes)
            | 'Decode bytes' >> beam.Map(lambda x: x.decode('utf-8'))
            | 'Parse and Enrich JSON' >> beam.ParDo(ParseMessage())
            | 'Write to BigQuery' >> beam.io.WriteToBigQuery(
                output_table,
                schema='user_id:INTEGER, action:STRING, timestamp:TIMESTAMP, event_date:DATE',
                write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND,
                create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
                method='STREAMING_INSERTS'
            )
        )

if __name__ == '__main__':
    run()
