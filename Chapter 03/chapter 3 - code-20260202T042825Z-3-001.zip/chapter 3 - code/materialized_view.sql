CREATE MATERIALIZED VIEW XXXX.bpb_data_engg_sales_db.sales_by_south_region
AS (
SELECT
 Product_Category,
  Product_ID,
 Sale_Date,
 Sales_Rep
FROM
 XXXX.bpb_data_engg_sales_db.sales_db
WHERE
 Region="South"
);
