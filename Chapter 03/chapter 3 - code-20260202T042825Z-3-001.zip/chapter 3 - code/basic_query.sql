SELECT
  Product_Category,
  round(sum(Sales_Amount)) as TOTAL_SALES
FROM
  `XXXX.bpb_data_engg_sales_db.sales_db`
WHERE
  Sale_Date > "2023-01-01" and Sale_Date < "2023-12-31"
GROUP BY
  Product_Category
ORDER BY
  TOTAL_SALES
