CREATE ROW ACCESS POLICY
  east_region_filter
ON
  bpb_data_engg_sales_db.sales_db GRANT TO ("user:XXXX")
FILTER USING
 (Region='East')
