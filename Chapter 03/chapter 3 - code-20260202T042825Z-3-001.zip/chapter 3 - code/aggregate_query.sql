SELECT region, COUNT(*) AS num_orders, AVG(sales_amount) AS avg_order_value
FROM bpb_data_engg_sales_db.sales_db
WHERE sale_date >= '2023-01-01' and sale_date <= '2023-12-31'
GROUP BY region
HAVING avg_order_value > 1000;
