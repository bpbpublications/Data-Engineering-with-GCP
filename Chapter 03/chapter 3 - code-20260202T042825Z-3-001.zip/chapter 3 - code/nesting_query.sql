SELECT
  order_id,
  customer_info.name,
  customer_info.address.city
FROM sales.orders;
