SELECT
  order_id,
  item.item_id,
  item.quantity
FROM sales.orders, UNNEST(items) AS item;
