import json
import os
import functions_framework
from google.cloud import storage
from google.cloud import pubsub_v1
from flask import jsonify
from datetime import datetime

@functions_framework.http
def process_sales_data(request):
    """
    Cloud Run function that processes sales data from a GCS bucket
    and publishes the results to a Pub/Sub topic called 'sales-topic'.
    
    Request format should be:
    {
        "bucket_name": "bpb_data_engg_sales_data_files",
        "file_path": "cdc/sales_data_20250521.json"
    }
    """
    # CORS headers for browser requests
    if request.method == 'OPTIONS':
        headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Max-Age': '3600'
        }
        return ('', 204, headers)
    
    headers = {
        'Access-Control-Allow-Origin': '*'
    }
    
    try:
        # Get request data
        request_json = request.get_json(silent=True)
        
        if not request_json:
            return jsonify({'error': 'No request data provided'}), 400, headers
            
        # Extract parameters
        bucket_name = request_json.get('bucket_name')
        file_path = request_json.get('file_path')
        
        if not bucket_name or not file_path:
            return jsonify({'error': 'Missing required parameters: bucket_name and file_path'}), 400, headers
        
        # Get data from GCS
        client = storage.Client()
        bucket = client.bucket(bucket_name)
        blob = bucket.blob(file_path)
        
        # Download and parse the JSON data
        content = blob.download_as_string()
        sales_data = json.loads(content)[0]
        
        # Publish to Pub/Sub
        publish_result = publish_to_pubsub('sales-topic', sales_data)
        
        return jsonify({
            'success': True,
            'message': f'Successfully processed {len(sales_data)} records and published to Pub/Sub',
            'records_processed': len(sales_data),
            # 'summary': processed_data,
            'pubsub_message_id': publish_result
        }), 200, headers
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500, headers

def publish_to_pubsub(topic_name, message_data):
    """
    Publishes a message to a Pub/Sub topic.
    
    Args:
        topic_name: Name of the Pub/Sub topic (without the projects/PROJECT_ID prefix)
        message_data: Dictionary containing the message data
        
    Returns:
        The message ID from Pub/Sub
    """
    # Initialize a Publisher client
    publisher = pubsub_v1.PublisherClient()
    
    # Replace with your project Id
    project_id = '******'
    if not project_id:
        # Try to get it from the credentials
        _, project_id = publisher._get_credentials_and_project_id()
        
    if not project_id:
        raise ValueError("Could not determine GCP project ID. Please set GCP_PROJECT environment variable.")
    
    # Format the topic path
    topic_path = publisher.topic_path(project_id, topic_name)
    
    # Convert message to JSON string and then to bytes
    message_json = json.dumps(message_data)
    message_bytes = message_json.encode('utf-8')
    
    # Publish the message
    publish_future = publisher.publish(topic_path, data=message_bytes)
    message_id = publish_future.result()
    
    print(f"Published message to {topic_path} with ID: {message_id}")
    return message_id