from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.python import PythonOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
import json
from google.cloud import storage
from google.cloud.sql.connector import Connector
import sqlalchemy
from airflow.models.variable import Variable
import requests
from datetime import date, datetime

#import psycopg2

def query_cloud_sql(**kwargs):
    last_execution_time = Variable.get("last_execution_time", default_var=None)
    current_execution_time = kwargs['execution_date']
    Variable.set("last_execution_time", str(current_execution_time))
    # Convert last_execution_time to datetime if it exists
    if last_execution_time:
        last_execution_time = datetime.fromisoformat(last_execution_time)
    else:
        last_execution_time = current_execution_time - timedelta(hours=1)  # Default to 1 hour ago
    connector = Connector()
    conn = connector.connect(
        "****:us-central1:bpb-postgre-sql-1",
        "pg8000",
        user="postgres",
        password=Variable.get("cloud_sql_postgres_password"),
        db="postgres"
    )    
    # Using SQLAlchemy with explicit binding parameters
    engine = sqlalchemy.create_engine("postgresql+pg8000://", creator=lambda: conn)    
    # Make sure to use the correct schema and table name
    query = sqlalchemy.text("""
        SELECT Product_ID, Sales_Date, Sales_Rep, Region, Sales_Amount, Quantity_Sold,
               Product_Category, Unit_Cost, Unit_Price, Customer_Type, Discount,
               Payment_Method, Sales_Channel, Region_and_Sales_Rep
        FROM public.sales
        WHERE last_updated >= :start_time AND last_updated < :end_time
    """)    
    # Execute the query using standard SQLAlchemy methods
    connection = engine.connect()
    try:
        result = connection.execute(
            query, 
            {"start_time": last_execution_time, "end_time": current_execution_time}
        )       
        # Convert SQLAlchemy Row objects to dictionaries for proper serialization
        column_names = result.keys()
        rows_as_dicts = [dict(zip(column_names, row)) for row in result.fetchall()]       
        # Process datetime objects to make them JSON serializable
        for row in rows_as_dicts:
            for key, value in row.items():
                if isinstance(value, datetime):
                    row[key] = value.isoformat()      
        return rows_as_dicts
    finally:
        connection.close()
        conn.close()

def write_to_gcs(**kwargs):    
    # JSON encoder to handle date and datetime objects
    class DateTimeEncoder(json.JSONEncoder):
        def default(self, obj):
            if isinstance(obj, (date, datetime)):
                return obj.isoformat()
            return super().default(obj)    
    ti = kwargs['ti']
    rows = ti.xcom_pull(task_ids='query_cloud_sql')
    client = storage.Client()
    bucket = client.bucket('bpb_data_engg_sales_data_files')
    blob = bucket.blob(f'cdc/sales_data_{kwargs["ds_nodash"]}.json')   
    json_data = json.dumps(rows, cls=DateTimeEncoder)
    blob.upload_from_string(json_data)   
    print(f"Successfully wrote {len(rows)} records to GCS bucket")
    return f"gs://bpb_data_engg_sales_data_files/cdc/sales_data_{kwargs['ds_nodash']}.json"

def invoke_cloud_run_function(**kwargs):
    """
    Invokes the Cloud Run function to process the sales data.
    Gets the GCS file path from the previous task using XCom.
    """
    ti = kwargs['ti']
    
    # Get the GCS path from the previous task
    gcs_path = ti.xcom_pull(task_ids='write_to_gcs')
    
    if not gcs_path:
        print("No GCS path found from previous task. Check if write_to_gcs completed successfully.")
        return None
    
    # Extract bucket and file path from the gs:// URL
    # Format: gs://bucket_name/file_path
    parts = gcs_path.replace('gs://', '').split('/', 1)
    bucket_name = parts[0]
    file_path = parts[1]
    
    # Cloud Run function URL - replace with your actual Cloud Run function URL
    cloud_run_url = "https://***********"
    
    # Prepare request payload
    payload = {
        "bucket_name": bucket_name,
        "file_path": file_path
    }
    
    # Invoke the Cloud Run function
    try:
        response = requests.post(
            cloud_run_url,
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        
        # Check if the request was successful
        response.raise_for_status()
        
        # Parse and return the response
        result = response.json()
        print(f"Cloud Run function processed {result.get('records_processed', 0)} records")
        return result
        
    except requests.exceptions.RequestException as e:
        print(f"Error invoking Cloud Run function: {e}")
        if hasattr(e, 'response') and e.response is not None:
            print(f"Response content: {e.response.content}")
        raise

default_args = {
    'owner': 'bpb',
    'depends_on_past': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
    'max_active_tasks': 16,
}

with DAG(
    dag_id='sales_etl_pipeline',
    default_args=default_args,
    description='ETL pipeline for sales data',
    schedule_interval=None, 
    start_date=datetime(2025, 5, 19),
    catchup=False,
    max_active_runs=3,
) as dag:
    query_cloud_sql = PythonOperator(
        task_id='query_cloud_sql',
        python_callable=query_cloud_sql,
        provide_context=True,
    )
    write_to_gcs = PythonOperator(
        task_id='write_to_gcs',
        python_callable=write_to_gcs,
        provide_context=True,
    )
    trigger_cloud_run = PythonOperator(
        task_id='trigger_cloud_run',
        python_callable=invoke_cloud_run_function,
        provide_context=True,
    )

    validate_bq = BigQueryInsertJobOperator(
        task_id='validate_bq',
        configuration={
            'query': {
                'query': 'SELECT COUNT(*) as record_count FROM bpb_data_engg_sales_db.regional_sales_db WHERE Sales_Date = "{{ ds }}"',
                'useLegacySql': False,
            }
        },
        gcp_conn_id='google_cloud_default',
    )

query_cloud_sql >> write_to_gcs >> trigger_cloud_run >> validate_bq